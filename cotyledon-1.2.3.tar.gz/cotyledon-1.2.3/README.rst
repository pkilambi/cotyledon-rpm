===============================
Cotyledon
===============================

Cotyledon provides a framework for defining long-running services.

* Free software: Apache license
* Documentation: http://docs.openstack.org/developer/cotyledon
* Source: http://git.openstack.org/cgit/openstack/cotyledon
* Bugs: http://bugs.launchpad.net/replace with the name of the project on launchpad
