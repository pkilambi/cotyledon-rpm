========
API
========

.. autoclass:: cotyledon.Service
   :members:
   :special-members: __init__

.. autoclass:: cotyledon.ServiceManager
   :members:
   :special-members: __init__
